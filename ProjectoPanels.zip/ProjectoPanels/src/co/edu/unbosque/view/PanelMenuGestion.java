package co.edu.unbosque.view;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * PanelMenuGestion es un panel de la interfaz gráfica que representa el menú de
 * gestión para el sistema. Contiene botones para agregar, mostrar, actualizar,
 * eliminar productos, y volver al menú principal. Además, incluye imágenes de
 * fondo específicas para cada tipo de producto.
 */

public class PanelMenuGestion extends JPanel {
	
	private JButton btnAgregar, btnMostrar, btnActualizar, btnEliminar, btnVolver;

	/**
	 * Constructor de PanelMenuGestion. Inicializa el panel con botones para las
	 * acciones de gestión y con imágenes de fondo específicas para cada tipo de
	 * producto.
	 */
	public PanelMenuGestion() {

		setLayout(null);
		setVisible(true);
		setSize(1280, 720);

		btnAgregar = new JButton("agregar");
		btnAgregar.setBounds(483, 270, 140, 130);
		btnAgregar.setOpaque(false);
		btnAgregar.setActionCommand("AGREGAR");

		btnMostrar = new JButton("mostrar");
		btnMostrar.setBounds(640, 270, 170, 130);
		btnMostrar.setOpaque(false);
		btnMostrar.setActionCommand("MOSTRAR");

		btnActualizar = new JButton("actualizar");
		btnActualizar.setBounds(483, 400, 140, 130);
		btnActualizar.setOpaque(false);
		btnActualizar.setActionCommand("ACTUALIZAR");

		btnEliminar = new JButton("eliminar");
		btnEliminar.setBounds(640, 400, 170, 130);
		btnEliminar.setOpaque(false);
		btnEliminar.setActionCommand("ELIMINAR");

		btnVolver = new JButton("volver");
		btnVolver.setBounds(570, 530, 160, 125);
		btnVolver.setOpaque(false);
		btnVolver.setActionCommand("VOLVER");

		
		add(btnAgregar);
		add(btnMostrar);
		add(btnActualizar);
		add(btnEliminar);
		add(btnVolver);

	}
	/**
	 * Obtiene el botón de "agregar" del panel.
	 * 
	 * @return El botón de "agregar".
	 */
	public JButton getBtnAgregar() {
		return btnAgregar;
	}

	/**
	 * Establece el botón de "agregar" del panel.
	 * 
	 * @param btnAgregar El nuevo botón de "agregar".
	 */
	public void setBtnAgregar(JButton btnAgregar) {
		this.btnAgregar = btnAgregar;
	}

	/**
	 * Obtiene el botón de "mostrar" del panel.
	 * 
	 * @return El botón de "mostrar".
	 */
	public JButton getBtnMostrar() {
		return btnMostrar;
	}

	/**
	 * Establece el botón de "mostrar" del panel.
	 * 
	 * @param btnMostrar El nuevo botón de "mostrar".
	 */
	public void setBtnMostrar(JButton btnMostrar) {
		this.btnMostrar = btnMostrar;
	}

	/**
	 * Obtiene el botón de "actualizar" del panel.
	 * 
	 * @return El botón de "actualizar".
	 */
	public JButton getBtnActualizar() {
		return btnActualizar;
	}

	/**
	 * Establece el botón de "actualizar" del panel.
	 * 
	 * @param btnActualizar El nuevo botón de "actualizar".
	 */
	public void setBtnActualizar(JButton btnActualizar) {
		this.btnActualizar = btnActualizar;
	}

	/**
	 * Obtiene el botón de "eliminar" del panel.
	 * 
	 * @return El botón de "eliminar".
	 */
	public JButton getBtnEliminar() {
		return btnEliminar;
	}

	/**
	 * Establece el botón de "eliminar" del panel.
	 * 
	 * @param btnEliminar El nuevo botón de "eliminar".
	 */
	public void setBtnEliminar(JButton btnEliminar) {
		this.btnEliminar = btnEliminar;
	}

	/**
	 * Obtiene el botón de "volver" del panel.
	 * 
	 * @return El botón de "volver".
	 */
	public JButton getBtnVolver() {
		return btnVolver;
	}

	/**
	 * Establece el botón de "volver" del panel.
	 * 
	 * @param btnVolver El nuevo botón de "volver".
	 */
	public void setBtnVolver(JButton btnVolver) {
		this.btnVolver = btnVolver;
	}

}