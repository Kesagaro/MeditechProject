package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.CardLayout;
import java.awt.Color;

public class View extends JFrame {
    private PanelInicio panelInicio;
    private LoginPanel loginPanel;

    public View() {
        setTitle("Login Application");
        setSize(550, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        panelInicio = new PanelInicio();
      //add(panelInicio); // Agregar el panel al JFrame
        loginPanel = new LoginPanel();
        
      //CardLayaout para cambiar entre paneles https://docs.oracle.com/javase/8/docs/api/java/awt/CardLayout.html
        CardLayout cardLayout = new CardLayout();
        JPanel mainPanel = new JPanel(cardLayout);
        mainPanel.add(panelInicio, "PanelInicio");
        mainPanel.add(loginPanel, "LoginPanel");
        
        setContentPane(mainPanel);
        
        // Cambiar el color de fondo de la ventana
        getContentPane().setBackground(new Color(255, 255, 255)); // Fondo blanco

        setVisible(true);
    }

    public PanelInicio getPanelInicio() {
        return panelInicio;
    }
    
    public LoginPanel getLoginPanel() {
        return loginPanel;
    }
    
    public void showLoginPanel() {
    	CardLayout cl = (CardLayout) (getContentPane().getLayout());
    	cl.show(getContentPane(), "MEDITECH");//Metodo para mostrar el Login Panel
    }
    
    
}