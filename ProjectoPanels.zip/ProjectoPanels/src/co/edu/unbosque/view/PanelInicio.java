package co.edu.unbosque.view;
import javax.swing.*;
import java.awt.*;

public class PanelInicio extends JPanel {
    private RoundedButton loginButton;
    private RoundedButton registerButton;
    private RoundedButton listButton;

    public PanelInicio() {
        setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10)); // Usar FlowLayout para centrar

        // Crear el panel glassmorphism
        GlassmorphismPanel glassPanel = new GlassmorphismPanel();
        glassPanel.setLayout(new BoxLayout(glassPanel, BoxLayout.Y_AXIS));
        glassPanel.setPreferredSize(new Dimension(300, 300)); // Tamaño 

        // Agregar un espaciador en la parte superior
        glassPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Espacio de 20 píxeles

        //imagen
        ImageIcon imageIcon = new ImageIcon("src/BosqueFarma.png"); // Cambia la ruta a la ubicación de tu imagen
        Image img = imageIcon.getImage(); // Obtener la imagen
        Image newImg = img.getScaledInstance(200, 100, Image.SCALE_SMOOTH); // Redimensionar la imagen
        imageIcon = new ImageIcon(newImg); // Crear un nuevo ImageIcon con la imagen redimensionada

        JLabel imageLabel = new JLabel(imageIcon, SwingConstants.CENTER);
        imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Alinear la imagen al centro
        glassPanel.add(imageLabel); // Agregar la imagen al panel de glassmorphism

        // Crear botones con estilos
        loginButton = new RoundedButton("Login");
        registerButton = new RoundedButton("Register");
        listButton = new RoundedButton("Lista de funcionarios");

        // Agregar botones al panel de glassmorphism
        glassPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre la imagen y los botones
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT); // Alinear el botón al centro
        glassPanel.add(loginButton);
        glassPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        registerButton.setAlignmentX(Component.CENTER_ALIGNMENT); // Alinear el botón al centro
        glassPanel.add(registerButton);
        glassPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio entre botones
        listButton.setAlignmentX(Component.CENTER_ALIGNMENT); // Alinear el botón al centro
        glassPanel.add(listButton);
        // Agregar el panel de glassmorphism al panel principal
        add(glassPanel);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Crear el degradado
        GradientPaint gradient = new GradientPaint(0, 0, new Color(128, 0, 128), 0, getHeight(), new Color(0, 0, 255));
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());
    }

    public RoundedButton getLoginButton() {
        return loginButton;
    }

    public RoundedButton getRegisterButton() {
        return registerButton;
    }

    public RoundedButton getListButton() {
        return listButton;
    }
}