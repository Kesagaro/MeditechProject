package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class TransparentPanel extends JPanel {
    private Color backgroundColor;

    public TransparentPanel() {
        this.backgroundColor = new Color(255, 255, 255, 150); // Color blanco con transparencia
        setOpaque(false); // Hacer panel sea transparente
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Crear un fondo difuminado
        g2d.setColor(new Color(255, 255, 255, 100)); // Color blanco con un poco de transparencia
        g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20); // Rellenar el panel con esquinas redondeadas
    }
}