package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;

public class LoginPanel extends JPanel {
	private JTextField cedulaField;
	private JPasswordField passwordField;
	private CustomBotones loginButton;

	public LoginPanel() {
		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(10, 10, 10, 10); // Espacio entre componentes

		// Etiqueta y campo para la cédula
		gbc.gridx = 0;
		gbc.gridy = 0;
		add(new JLabel("Cédula:"), gbc);

		cedulaField = new JTextField(15);
		gbc.gridx = 1;
		add(cedulaField, gbc);

		// Etiqueta y campo para la contraseña
		gbc.gridx = 0;
		gbc.gridy = 0;
		add(new JLabel("Contraseña:"), gbc);

		passwordField = new JPasswordField(15);
		gbc.gridx = 1;
		add(passwordField, gbc);

		// Boton Login
		loginButton = new CustomBotones("Login");
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 2; // ocupa dos columnas
		gbc.anchor = GridBagConstraints.CENTER; // Centra el boton
		add(loginButton, gbc);
	}

	public CustomBotones getLoginButton() {
		return loginButton;
	}
	
	public String getCedula() {
		return cedulaField.getText();
	}
	
	public String getPassword() {
		return new String(passwordField.getPassword());
	}
	
}
