package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.Image;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

/**
 * PanelInventario es un panel de la interfaz gráfica que permite la entrada de
 * datos para productos. Incluye campos de texto para ingresar información del
 * producto, botones para agregar, actualizar, importar imágenes y volver, así
 * como etiquetas de imagen para mostrar detalles adicionales según el tipo de
 * producto.
 */

public class PanelInventario extends JPanel {
	private JLabel  imagenAgregarP;
	private JTextField numId, nombre, empresa, precio, cantidad, atributoPropio1, atributoPropio2, atributoPropio3;
	private JButton btnVolver, btnAgregar, btnJFileChooser, btnActualizar;

	/**
	 * Constructor de la clase PanelEntrada. Inicializa y configura todos los
	 * componentes gráficos del panel, incluyendo campos de texto, botones y
	 * etiquetas de imagen, así como las propiedades del panel.
	 */
	public PanelInventario() {
		
	}
}
