package co.edu.unbosque.model;

public class Turno {

}
