package co.edu.unbosque.model;

import co.edu.unbosque.model.persistence.*;

public class ClaseX {
	private FuncionarioDAO funcionarioDAO;
	private MedicamentoDAO medicamentoDAO;
	private TurnoDAO turnoDAO;

	public ClaseX() {
		funcionarioDAO = new FuncionarioDAO();
		medicamentoDAO = new MedicamentoDAO();
		turnoDAO = new TurnoDAO();
	}
	public void crearFuncionario(FuncionarioDTO data) {
		funcionarioDAO.crear(data);
	}
	public String mostrarFuncionarios() {
		return funcionarioDAO.mostrar();
	}
	public void crearMedicamento(MedicamentoDTO data) {
		medicamentoDAO.crear(data);
	}
	public String mostrarMedicamentos() {
		return medicamentoDAO.mostrar();
	}
	public void crearTurno(TurnoDTO data) {
		turnoDAO.crear(data);
	}
	public String mostrarTurnos() {
		return turnoDAO.mostrar();
	}

}
