package co.edu.unbosque.model.persistence;

public class TurnoDTO {
	private int numeroTurno;
	private String documentoPaciente;
	private String estado;
	
	public TurnoDTO(int numeroTurno, String documentoPaciente, String estado) {
		this.documentoPaciente = documentoPaciente;
		this.estado = estado;
		this.numeroTurno = numeroTurno;
	}

	//Getters y Setters
	
	public int getNumeroTurno() {
		return numeroTurno;
	}

	public void setNumeroTurno(int numeroTurno) {
		this.numeroTurno = numeroTurno;
	}

	public String getDocumentoPaciente() {
		return documentoPaciente;
	}

	public void setDocumentoPaciente(String documentoPaciente) {
		this.documentoPaciente = documentoPaciente;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	
	
}
