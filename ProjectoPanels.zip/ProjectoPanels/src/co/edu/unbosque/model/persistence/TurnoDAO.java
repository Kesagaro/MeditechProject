package co.edu.unbosque.model.persistence;

import java.util.ArrayList;
import java.util.List;

public class TurnoDAO implements Crud<TurnoDTO> {
	private List<TurnoDTO> turnos;

	public TurnoDAO() {
		turnos = new ArrayList<>();
	}

	@Override
	public void crear(TurnoDTO data) {
		turnos.add(data);
	}

	@Override
	public String mostrar() {
		StringBuilder sb = new StringBuilder();
		for (TurnoDTO turno : turnos) {
			sb.append("Número de Turno: ").append(turno.getNumeroTurno()).append("\n");
			sb.append("Documento Paciente: ").append(turno.getDocumentoPaciente()).append("\n");
			sb.append("Estado: ").append(turno.getEstado()).append("\n\n");
		}
		return sb.toString();
	}

	@Override
	public String actualizar(int index, TurnoDTO newData) {
		if (index >= 0 && index < turnos.size()) {
			turnos.set(index, newData);
			return "Turno actualizado correctamente.";
		} else {
			return "Índice inválido.";
		}
	}

	@Override
	public String eliminarPorNombre(String name) {
		for (TurnoDTO turno : turnos) {
			if (String.valueOf(turno.getNumeroTurno()).equals(name)) {
				turnos.remove(turno);
				return "Turno eliminado correctamente.";
			}
		}
		return "Turno no encontrado.";
	}

	@Override
	public String checkearIndex(int index) {
		if (index >= 0 && index < turnos.size()) {
			return "Índice válido.";
		} else {
			return "Índice inválido.";
		}
	}
}
