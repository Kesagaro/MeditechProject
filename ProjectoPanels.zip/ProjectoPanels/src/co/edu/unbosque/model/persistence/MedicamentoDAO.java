package co.edu.unbosque.model.persistence;

import java.util.ArrayList;
import java.util.List;

public class MedicamentoDAO implements Crud<MedicamentoDTO> {
	private List<MedicamentoDTO> medicamentos;

	public MedicamentoDAO() {
		medicamentos = new ArrayList<>();
	}

	@Override
	public void crear(MedicamentoDTO data) {
		medicamentos.add(data);
	}

	@Override
	public String mostrar() {
		StringBuilder sb = new StringBuilder();
		for (MedicamentoDTO medicamento : medicamentos) {
			sb.append("Número ID;: ").append(medicamento.getNumId()).append("\n");
			sb.append("Nombre: ").append(medicamento.getNombre()).append("\n");
			sb.append("Empresa: ").append(medicamento.getEmpresa()).append("\n");
			sb.append("Precio: ").append(medicamento.getPrecio()).append("\n");
			sb.append("Cantidad: ").append(medicamento.getCantidad()).append("\n\n");
		}
		return sb.toString();
	}

	@Override
	public String actualizar(int index, MedicamentoDTO newData) {
		if (index >= 0 && index < medicamentos.size()) {
			medicamentos.set(index, newData);
			return "Medicamento actualizado correctamente.";
		} else {
			return "Índice inválido.";
		}
	}

	@Override
	public String eliminarPorNombre(String name) {
		for (MedicamentoDTO medicamento : medicamentos) {
			if (medicamento.getNombre().equals(name)) {
				medicamentos.remove(medicamento);
				return "Medicamento eliminado correctamente.";
			}
		}
		return "Medicamento no encontrado.";
	}

	@Override
	public String checkearIndex(int index) {
		if (index >= 0 && index < medicamentos.size()) {
			return "Índice válido.";
		} else {
			return "Índice inválido.";
		}
	}

}
