package co.edu.unbosque.model.persistence;

public class FuncionarioDTO {
	private String nombreCompleto;
	private String cedula;
	private String password;
	private String correo;
	
	public FuncionarioDTO(String nombreCompleto, String cedula, String password, String correo) {
		this.nombreCompleto = nombreCompleto;
		this.cedula = cedula;
		this.correo = correo;
		this.password = password;
	}
	//getter y setters

	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	public String getCedula() {
		return cedula;
	}

	public void setCedula(String cedula) {
		this.cedula = cedula;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
}
