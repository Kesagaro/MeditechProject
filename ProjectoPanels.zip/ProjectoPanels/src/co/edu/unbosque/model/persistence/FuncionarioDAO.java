package co.edu.unbosque.model.persistence;

import java.util.ArrayList;
import java.util.List;

public class FuncionarioDAO implements Crud<FuncionarioDTO>{
	private List<FuncionarioDTO> funcionarios;
	
	public FuncionarioDAO() {
		funcionarios = new ArrayList<>();
	}

	@Override
	public void crear(FuncionarioDTO data) {
		// TODO Auto-generated method stub
		funcionarios.add(data);
	}

	@Override
	public String mostrar() {
		StringBuilder sb = new StringBuilder();
		for(FuncionarioDTO funcionario : funcionarios) {
			sb.append("Nombre Completo: ").append(funcionario.getNombreCompleto()).append("\n");
			sb.append("Cedula: ").append(funcionario.getCedula()).append("\n");
			sb.append("Correo: ").append(funcionario.getCorreo()).append("\n\n");
		}
		return sb.toString();
	}

	@Override
	public String actualizar(int index, FuncionarioDTO newData) {
		// TODO Auto-generated method stub
		if (index >= 0 && index < funcionarios.size()) {
			funcionarios.set(index, newData);
			return "Funcionario actualizado correctamente.";
		}else {
			return "Indice inválido.";
		}
	}

	@Override
	public String eliminarPorNombre(String name) {
		for(FuncionarioDTO funcionario : funcionarios) {
			if(funcionario.getNombreCompleto().equals(name)) {
				funcionarios.remove(funcionario);
				return "Funcionario eliminado correctamente";
			}
		}
		return "Funcionario no encontrado";
	}

	@Override
	public String checkearIndex(int index) {
		if (index >= 0 && index < funcionarios.size()) {
			return "Indice válido.";
		}else {
			return "Indice inválido.";
		}
	}
}
