package co.edu.unbosque.model;

public class UserRegister extends User{

}
