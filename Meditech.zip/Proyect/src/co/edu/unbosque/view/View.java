package co.edu.unbosque.view;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

import co.edu.unbosque.controller.Controller;

public class View extends JFrame {
    private PanelEntrada panelEntrada;
    private PanelResultados panelResultados;

    public View(Controller controller) {
        super("Bosque Farma");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        panelEntrada = new PanelEntrada();
        panelResultados = new PanelResultados();
        add(panelEntrada, BorderLayout.NORTH);
        add(panelResultados, BorderLayout.CENTER);
        pack();
        setVisible(true);
    }

    public PanelEntrada getPanelEntrada() {
        return panelEntrada;
    }

    public PanelResultados getPanelResultados() {
        return panelResultados;
    }
}