package co.edu.unbosque.model;

public class Turno {
    private String documentoPaciente;
    private String estado;

    public Turno(String documentoPaciente) {
        this.documentoPaciente = documentoPaciente;
        this.estado = "por atender";
    }

	
}