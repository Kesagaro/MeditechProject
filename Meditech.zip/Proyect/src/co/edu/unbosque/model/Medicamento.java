package co.edu.unbosque.model;

public class Medicamento {
    private String codigo;
    private String nombre;
    private int cantidad;

    public Medicamento(String codigo, String nombre, int cantidad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.cantidad = cantidad;
    }

	
}