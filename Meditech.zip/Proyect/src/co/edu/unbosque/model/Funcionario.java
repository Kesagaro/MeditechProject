package co.edu.unbosque.model;

public class Funcionario {
    private String nombre;
    private String cedula;
    private String contraseña;
    private String correo;

    public Funcionario(String nombre, String cedula, String contraseña, String correo) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.contraseña = contraseña;
        this.correo = correo;
    }

	
}