package co.edu.unbosque.model;

import java.util.ArrayList;

public class Meditech {
    private ArrayList<Funcionario> listaFuncionarios;
    private ArrayList<Medicamento> listaMedicamentos;
    private ArrayList<Turno> listaTurnos;

    public Meditech() {
        listaFuncionarios = new ArrayList<>();
        listaMedicamentos = new ArrayList<>();
        listaTurnos = new ArrayList<>();
    }

    public void agregarFuncionario(String nombre, String cedula, String contraseña, String correo) {
        Funcionario nuevoFuncionario = new Funcionario(nombre, cedula, contraseña, correo);
        listaFuncionarios.add(nuevoFuncionario);
    }

    public void agregarMedicamento(String codigo, String nombre, int cantidad) {
        Medicamento nuevoMedicamento = new Medicamento(codigo, nombre, cantidad);
        listaMedicamentos.add(nuevoMedicamento);
    }

    public void asignarTurno(String documentoPaciente) {
        Turno nuevoTurno = new Turno(documentoPaciente);
        listaTurnos.add(nuevoTurno);
    }

    public ArrayList<Funcionario> getListaFuncionarios() {
        return listaFuncionarios;
    }

    public ArrayList<Medicamento> getListaMedicamentos() {
        return listaMedicamentos;
    }

    public ArrayList<Turno> getListaTurnos() {
        return listaTurnos;
    }
}