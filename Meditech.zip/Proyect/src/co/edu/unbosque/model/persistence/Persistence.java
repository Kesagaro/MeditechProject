package co.edu.unbosque.model.persistence;

import co.edu.unbosque.model.Funcionario;
import co.edu.unbosque.model.Medicamento;
import co.edu.unbosque.model.Turno;
import co.edu.unbosque.model.*;

public class Persistence {
    
}