package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import co.edu.unbosque.model.Meditech;
import co.edu.unbosque.model.ClaseX;
import co.edu.unbosque.view.View;

public class Controller implements ActionListener {
    private Meditech model;
    private View gui;
    private ClaseX claseX;

    public Controller() {
        model = new Meditech();
        claseX = new ClaseX();
        gui = new View(this);
        gui.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        
    }
}