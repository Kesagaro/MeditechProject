import javax.swing.*;
import java.awt.Color;

public class View extends JFrame {
    private PanelInicio panelInicio;

    public View() {
        setTitle("Login Application");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        panelInicio = new PanelInicio();
        add(panelInicio); // Agregar el panel al JFrame

        // Cambiar el color de fondo de la ventana
        getContentPane().setBackground(new Color(255, 255, 255)); // Fondo blanco

        setVisible(true);
    }

    public PanelInicio getPanelInicio() {
        return panelInicio;
    }
}