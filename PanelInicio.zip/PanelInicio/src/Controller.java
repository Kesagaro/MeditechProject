import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
public class Controller {
    private View view;

    public Controller(View view) {
        this.view = view;

        // Agregar listeners a los botones
        view.getPanelInicio().getLoginButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(view, "Login clicked");
            }
        });

        view.getPanelInicio().getRegisterButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(view, "Register clicked");
            }
        });

        view.getPanelInicio().getListButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(view, "Lista de funcionarios clicked");
            }
        });
    }
}