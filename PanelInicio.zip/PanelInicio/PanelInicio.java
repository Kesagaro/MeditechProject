import javax.swing.*;
import java.awt.*;

public class PanelInicio extends JPanel {
    private RoundedButton loginButton;
    private RoundedButton registerButton;
    private RoundedButton listButton;

    public PanelInicio() {
        setLayout(new BorderLayout()); // Cambiar a BorderLayout para centrar el título

        // Cargar la imagen
        ImageIcon imageIcon = new ImageIcon("BosqueFarma.jpg"); // Cambia la ruta a la ubicación de tu imagen

        // Redimensionar la imagen
        Image img = imageIcon.getImage(); // Obtener la imagen
        Image newImg = img.getScaledInstance(350, 200, Image.SCALE_SMOOTH); // Redimensionar la imagen
        imageIcon = new ImageIcon(newImg); // Crear un nuevo ImageIcon con la imagen redimensionada

        JLabel imageLabel = new JLabel(imageIcon, SwingConstants.CENTER);
        add(imageLabel, BorderLayout.NORTH); // Agregar la imagen en la parte superior


        // Crear un panel para los botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false); // Hacer que el panel de botones sea transparente
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10)); // Centrar y espaciar botones

        // Crear botones con estilos
        loginButton = new RoundedButton("Login");
        registerButton = new RoundedButton("Register");
        listButton = new RoundedButton("Lista de funcionarios");

        // Agregar botones al panel de botones
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        buttonPanel.add(listButton);

        // Agregar el panel de botones al panel principal
        add(buttonPanel, BorderLayout.CENTER);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Crear el degradado
        GradientPaint gradient = new GradientPaint(0, 0, new Color(128, 0, 128),  // Morado
                0, getHeight(), new Color(0, 0, 255)); // Azul
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight()); // Rellenar el panel con el degradado
    }

    public RoundedButton getLoginButton() {
        return loginButton;
    }

    public RoundedButton getRegisterButton() {
        return registerButton;
    }

    public RoundedButton getListButton() {
        return listButton;
    }
}